# JARVIS personal-build security review

Changes in this source package:
- Sentry movement detection no longer silently activates the front camera. It emits a movement event only.
- SMS inbox reading remains supported through READ_SMS (and can fall back to notification-listener messages).
- SEND_SMS and RECEIVE_SMS manifest permissions were removed because the inspected source did not implement direct SMS sending or an SMS broadcast receiver.
- SMS and contacts are no longer included in the onboarding batch permission request; they remain individually requestable when their feature is used.

Important limitations identified during review:
- The current code reads the SMS inbox, but no direct SmsManager send implementation was found. Sending should be implemented using an explicit user-confirmed SMS compose flow, or a separately reviewed direct-send implementation.
- Contact search/read is implemented; contact creation/update was not found in the inspected service.
- android:usesCleartextTraffic="true" remains in the manifest because the app contains configurable local Home Assistant HTTP support and an HTTP ISS endpoint. This should be replaced with a scoped network-security configuration before a hardened release.
- Accessibility and notification-listener access are highly privileged Android settings. Enable them only after reviewing the on-screen disclosures.
- This is a source-level safety patch, not a verified compiled APK. Build and device-test it before installation.

Do not disable Google Play Protect as a workaround. A private sideloaded app can still be scanned or blocked.


## Security hardening update — 2026-11-22

### Implemented in this working copy
- AI API key, Telegram bot token, and Home Assistant access token are now stored through `flutter_secure_storage` using Android encrypted shared preferences backed by Android Keystore.
- On first initialization, existing values are migrated to encrypted storage and verified before the legacy SharedPreferences entries are removed. If migration fails, the legacy value is retained and loaded in memory so the app does not discard the only recoverable credential.
- Local-First Privacy Mode now validates that AI requests use an HTTP loopback endpoint and blocks Edge Neural TTS before any text is sent to Microsoft's cloud endpoint.
- The Local-First setting description now explains that separately enabled integrations such as Telegram and Home Assistant may still use the network.

### Deliberately not changed
- `android:usesCleartextTraffic="true"` remains because the current app uses HTTP for local Ollama and Home Assistant endpoints. Disabling cleartext globally without replacing those transports would break existing features. A future per-endpoint transport policy is needed.
- `android:requestLegacyExternalStorage` and the existing storage permissions remain because the current file-management features have not yet been mapped to a tested scoped-storage migration.
- Existing accessibility, notification-listener, Shizuku, SMS, contacts, camera, overlay, and app-usage permissions/services remain intact.
- Android default-assistant role integration is not added in this patch. A valid implementation requires a VoiceInteractionService + VoiceInteractionSessionService, session-to-Flutter invocation handling, and device-level verification. A role-request button without those components would be misleading and could leave the app ineligible for the assistant role.

### Verification limitations
This environment does not have the Flutter/Dart SDK available, so `flutter pub get`, `dart analyze`, automated tests, and APK compilation could not be run here. The added dependency must be resolved by Flutter in CI before building.
