import 'package:flutter/services.dart';

/// Flutter bridge for the on-device LiteRT-LM engine.
///
/// Downloads and runs the on-device model from app-private storage.
/// It never routes prompts to a cloud provider.
class LocalLlmService {
  LocalLlmService._() {
    _channel.setMethodCallHandler((call) async {
      if (call.method == 'downloadProgress') {
        final values = Map<Object?, Object?>.from(call.arguments as Map);
        onDownloadProgress?.call(
          (values['receivedBytes'] as num).toInt(),
          (values['totalBytes'] as num).toInt(),
        );
      }
    });
  }

  static final LocalLlmService instance = LocalLlmService._();
  static const MethodChannel _channel = MethodChannel('com.privateagent/local_ai');
  void Function(int receivedBytes, int totalBytes)? onDownloadProgress;


  Future<Map<String, dynamic>> downloadModel({
    void Function(int receivedBytes, int totalBytes)? onProgress,
  }) async {
    onDownloadProgress = onProgress;
    try {
      final result = await _channel.invokeMapMethod<String, dynamic>('downloadModel');
      return result ?? const <String, dynamic>{'downloaded': false};
    } finally {
      onDownloadProgress = null;
    }
  }

  Future<void> cancelDownload() async {
    await _channel.invokeMethod<bool>('cancelDownload');
  }

  Future<Map<String, dynamic>> loadModel(String fileName) async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'loadModel',
      {'fileName': fileName},
    );
    return result ?? const <String, dynamic>{'loaded': false};
  }

  Future<String> generate(String prompt) async {
    final result = await _channel.invokeMethod<String>(
      'generate',
      {'prompt': prompt},
    );
    return result ?? '';
  }

  Future<Map<String, dynamic>> status() async {
    final result = await _channel.invokeMapMethod<String, dynamic>('status');
    return result ?? const <String, dynamic>{'loaded': false, 'model': null};
  }

  Future<void> unloadModel() async {
    await _channel.invokeMethod<bool>('unloadModel');
  }
}
