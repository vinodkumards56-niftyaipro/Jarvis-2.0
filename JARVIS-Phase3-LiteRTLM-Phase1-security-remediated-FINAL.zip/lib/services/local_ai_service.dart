import 'dart:async';
import 'package:flutter/services.dart';

/// Flutter bridge for the explicitly selected on-device LiteRT-LM provider.
class LocalAiService {
  LocalAiService._();
  static final LocalAiService instance = LocalAiService._();
  static const MethodChannel _channel = MethodChannel('com.privateagent/local_ai');

  final StreamController<({int received, int total})> _progress =
      StreamController<({int received, int total})>.broadcast();
  bool _handlerInstalled = false;

  Stream<({int received, int total})> get downloadProgress {
    _installHandler();
    return _progress.stream;
  }

  void _installHandler() {
    if (_handlerInstalled) return;
    _handlerInstalled = true;
    _channel.setMethodCallHandler((call) async {
      if (call.method == 'downloadProgress' && call.arguments is Map) {
        final data = Map<dynamic, dynamic>.from(call.arguments as Map);
        _progress.add((
          received: (data['receivedBytes'] as num?)?.toInt() ?? 0,
          total: (data['totalBytes'] as num?)?.toInt() ?? 0,
        ));
      }
    });
  }

  Future<Map<String, dynamic>> status() async {
    final value = await _channel.invokeMapMethod<String, dynamic>('status');
    return value ?? <String, dynamic>{'loaded': false};
  }

  Future<void> downloadModel() async {
    _installHandler();
    await _channel.invokeMethod<dynamic>('downloadModel');
  }

  Future<void> cancelDownload() async {
    await _channel.invokeMethod<bool>('cancelDownload');
  }

  Future<void> loadModel() async {
    await _channel.invokeMethod<dynamic>(
      'loadModel',
      <String, dynamic>{'fileName': 'gemma-4-E2B-it.litertlm'},
    );
  }

  Future<String> generate(String prompt) async {
    final response = await _channel.invokeMethod<String>(
      'generate',
      <String, dynamic>{'prompt': prompt},
    );
    if (response == null || response.trim().isEmpty) {
      throw StateError('The local model returned an empty response.');
    }
    return response;
  }

  Future<void> unloadModel() async {
    await _channel.invokeMethod<dynamic>('unloadModel');
  }
}
