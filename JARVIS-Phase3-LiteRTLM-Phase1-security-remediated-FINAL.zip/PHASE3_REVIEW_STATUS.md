# JARVIS Phase 3 – LiteRT-LM review package

This package is based on the uploaded `JARVIS-security-hardened-working-copy_1.zip` and overlays the Phase 3 LiteRT-LM integration. It is a review candidate, not a verified release APK.

## Corrections made in this review copy
- Corrected the SHA-256 to the value published for the official upstream model file (`181938105e0eefd105961417e8da75903eacda102c4fce9ce90f50b97139a63c`).
- Pinned the model download URL to the model-file revision rather than the moving `main` branch.
- Fixed the local chat prompt separator to use actual newline characters.
- Added a local-only path for `chatStream`; previously the stream path still attempted an OpenAI-compatible HTTP request.
- Preserved the previously selected non-local provider when the user turns the local provider off.
- Moved downloader cancellation reset to the synchronous pre-start phase to avoid a cancel-before-worker-start race.

## Verified by source inspection
- The original archive and the Phase 3 overlay ZIP both pass ZIP integrity checks.
- LiteRT-LM API usage (`Engine`, `EngineConfig`, `Backend.CPU`, `initialize`, `createConversation`, `sendMessage`, `close`) matches the current Kotlin API guide at the time of review.
- The existing accessibility and speech channel names are retained; local AI uses a separate MethodChannel.
- Model weights are downloaded to app-private `filesDir/local_models`, not bundled into the APK.
- The model downloader checks expected content length and SHA-256 before finalizing the model.

## Not yet verified – do not treat as complete
- Flutter/Dart SDK is not installed in the build environment, so `flutter analyze`, `flutter test`, and `flutter build apk` could not be run.
- No Android device/emulator runtime test has been performed.
- The project ZIP contains no `.github/workflows` directory, so there is no included GitHub Actions workflow to run from this source package.
- The model file is approximately 2.59 GB; actual download and load performance must be tested on the target phone.
- The original app has no extracted source tree in the GitHub repository branch; the repo contains ZIP archives. This review copy has not been committed to GitHub.

## Next required verification
1. Run `flutter pub get`, `flutter analyze`, and `flutter test`.
2. Run `cd android && ./gradlew assembleDebug`.
3. Install the debug APK on the target Android phone.
4. Download the model over Wi-Fi, verify successful checksum, load it, test offline chat and chat streaming, unload it, and confirm cloud providers are not called when Gemma is selected.
5. Only after these pass, prepare the final release APK and commit the approved source to the development branch.
