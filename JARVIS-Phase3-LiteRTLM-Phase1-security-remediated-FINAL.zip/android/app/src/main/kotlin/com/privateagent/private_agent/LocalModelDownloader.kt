package com.privateagent.private_agent

import android.content.Context
import android.os.StatFs
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean

/** Foreground-session downloader for the pinned Gemma 4 E2B CPU model. */
class LocalModelDownloader(context: Context) {
    private val appContext = context.applicationContext
    private val cancelled = AtomicBoolean(false)
    @Volatile private var activeConnection: HttpURLConnection? = null

    companion object {
        const val MODEL_FILE = "gemma-4-E2B-it.litertlm"
        private const val MODEL_URL = "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/6e5c4f1/gemma-4-E2B-it.litertlm"
        private const val EXPECTED_BYTES = 2_588_147_712L
        private const val EXPECTED_SHA256 = "181938105e0eefd105961417e8da75903eacda102c4fce9ce90f50b97139a63c"
        private const val CONNECT_TIMEOUT_MS = 30_000
        private const val READ_TIMEOUT_MS = 60_000
    }

    /** Reset cancellation synchronously before the worker thread is started. */
    fun prepareForDownload() {
        cancelled.set(false)
    }

    fun cancel() {
        cancelled.set(true)
        activeConnection?.disconnect()
    }

    fun download(onProgress: (Long, Long) -> Unit): File {
        check(!cancelled.get()) { "Model download cancelled." }
        val directory = File(appContext.filesDir, "local_models")
        check((directory.exists() || directory.mkdirs()) && directory.isDirectory) {
            "Unable to create private model storage."
        }
        val finalFile = File(directory, MODEL_FILE)
        val partialFile = File(directory, "$MODEL_FILE.part")
        val available = StatFs(directory.absolutePath).availableBytes
        check(available >= EXPECTED_BYTES + 150L * 1024L * 1024L) {
            "Not enough free storage. Please free at least 2.75 GB before downloading."
        }
        if (finalFile.isFile && finalFile.length() == EXPECTED_BYTES && sha256(finalFile) == EXPECTED_SHA256) {
            onProgress(EXPECTED_BYTES, EXPECTED_BYTES)
            return finalFile
        }
        finalFile.delete()
        partialFile.delete()

        val connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            instanceFollowRedirects = true
            requestMethod = "GET"
            setRequestProperty("User-Agent", "JARVIS-Android/Phase3")
        }
        activeConnection = connection
        try {
            connection.connect()
            check(connection.responseCode in 200..299) {
                "Model server returned HTTP ${connection.responseCode}."
            }
            val advertisedLength = connection.contentLengthLong
            check(advertisedLength == EXPECTED_BYTES) {
                "Unexpected model size from server; download was stopped for safety."
            }
            var received = 0L
            val digest = MessageDigest.getInstance("SHA-256")
            connection.inputStream.use { input ->
                FileOutputStream(partialFile).use { output ->
                    val buffer = ByteArray(1024 * 1024)
                    while (true) {
                        check(!cancelled.get()) { "Model download cancelled." }
                        val count = input.read(buffer)
                        if (count < 0) break
                        output.write(buffer, 0, count)
                        digest.update(buffer, 0, count)
                        received += count
                        onProgress(received, EXPECTED_BYTES)
                    }
                    output.fd.sync()
                }
            }
            check(!cancelled.get()) { "Model download cancelled." }
            check(received == EXPECTED_BYTES && partialFile.length() == EXPECTED_BYTES) {
                "Model download was incomplete. Please retry."
            }
            val actualHash = digest.digest().joinToString("") { "%02x".format(it) }
            check(actualHash == EXPECTED_SHA256) {
                "Model integrity check failed (SHA-256 mismatch). The partial file was rejected."
            }
            check(partialFile.renameTo(finalFile)) { "Could not finalize the verified model file." }
            return finalFile
        } catch (error: Throwable) {
            partialFile.delete()
            throw error
        } finally {
            activeConnection = null
            connection.disconnect()
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
