package com.privateagent.private_agent

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Owns one LiteRT-LM engine and one persistent conversation.
 *
 * All LiteRT-LM calls, including close(), are serialized on this executor.
 * Model files are resolved only from the app-private local_models directory.
 */
class LocalLlmEngine(context: Context) {
    private val appContext = context.applicationContext
    private val owner: ExecutorService = Executors.newSingleThreadExecutor()
    private var engine: Engine? = null
    private var conversation: com.google.ai.edge.litertlm.Conversation? = null
    private var loadedFileName: String? = null

    fun load(fileName: String, callback: (Result<Map<String, Any>>) -> Unit) {
        owner.execute {
            try {
                require(fileName.isNotBlank() && File(fileName).name == fileName) {
                    "Invalid model file name."
                }
                val modelDirectory = File(appContext.filesDir, "local_models")
                if (!modelDirectory.exists() && !modelDirectory.mkdirs()) {
                    error("Could not create the private model directory.")
                }
                val modelFile = File(modelDirectory, fileName).canonicalFile
                require(modelFile.parentFile == modelDirectory.canonicalFile) {
                    "Model path is outside the private model directory."
                }
                require(modelFile.isFile && modelFile.canRead() && modelFile.length() > 0L) {
                    "Model file is missing or unreadable."
                }

                releaseLoadedModel()
                val candidate = Engine(
                    EngineConfig(
                        modelPath = modelFile.absolutePath,
                        backend = Backend.CPU(),
                        cacheDir = appContext.cacheDir.absolutePath
                    )
                )
                // If initialize throws, do not close this candidate: LiteRT-LM
                // documents that closing an uninitialized engine is invalid.
                candidate.initialize()
                try {
                    val candidateConversation = candidate.createConversation()
                    engine = candidate
                    conversation = candidateConversation
                    loadedFileName = fileName
                } catch (error: Throwable) {
                    candidate.close()
                    throw error
                }
                callback(Result.success(mapOf("loaded" to true, "model" to fileName)))
            } catch (error: Throwable) {
                callback(Result.failure(error))
            }
        }
    }

    fun generate(prompt: String, callback: (Result<String>) -> Unit) {
        owner.execute {
            try {
                require(prompt.isNotBlank()) { "Prompt cannot be empty." }
                val activeConversation = checkNotNull(conversation) {
                    "Local model is not loaded."
                }
                callback(Result.success(activeConversation.sendMessage(prompt).text))
            } catch (error: Throwable) {
                callback(Result.failure(error))
            }
        }
    }

    fun status(callback: (Map<String, Any?>) -> Unit) {
        owner.execute {
            callback(mapOf("loaded" to (engine != null), "model" to loadedFileName))
        }
    }

    fun unload(callback: (Result<Unit>) -> Unit) {
        owner.execute {
            try {
                releaseLoadedModel()
                callback(Result.success(Unit))
            } catch (error: Throwable) {
                callback(Result.failure(error))
            }
        }
    }

    private fun releaseLoadedModel() {
        val currentConversation = conversation
        conversation = null
        currentConversation?.close()

        val currentEngine = engine
        engine = null
        loadedFileName = null
        currentEngine?.close()
    }

    fun shutdown() {
        owner.execute {
            try {
                releaseLoadedModel()
            } finally {
                owner.shutdown()
            }
        }
    }
}
